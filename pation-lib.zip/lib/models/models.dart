import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';

class DatabaseService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  // جلب جميع الأطباء من Firestore
  Future<List<UserModel>> getDoctors() async {
    try {
      var snapshot = await _db
          .collection('users')
          .where('role', isEqualTo: 'doctor')
          .get();

      return snapshot.docs
          .map((doc) => UserModel.fromMap(doc.data(), doc.id))
          .toList();
    } catch (e) {
      print("Erreur lors du chargement des médecins: $e");
      return [];
    }
  }
}



// ===== MODELS (sans base de données) =====

class UserModel {
  final String id;
  final String username;
  final String email;
  final String role;
  // 'patient' or 'doctor'
  final String? nom;
  final String? dateNaissance;
  final String? sexe;
  final String? taille;
  final String? poids;
  // Doctor fields
  final String? nomProfessionnel;
  final String? specialite;
  final String? anciennete;
  final double? latitude;
  final double? longitude;

  UserModel({
    required this.id,
    required this.username,
    required this.email,
    required this.role,
    this.nom,
    this.dateNaissance,
    this.sexe,
    this.taille,
    this.poids,
    this.nomProfessionnel,
    this.specialite,
    this.anciennete,
    this.latitude,
    this.longitude,
  });
  factory UserModel.fromMap(Map<String, dynamic> map, String documentId) {
    return UserModel(
      id: documentId,
      username: map['username'] ?? '',
      email: map['email'] ?? '',
      role: map['role'] ?? '',
      nom: map['nom'],
      dateNaissance:map['dateNaissance'] ?? '',
      sexe: map['sexe'] ?? '',
      taille: map['taille'] ?? '',
      poids: map['poids'] ?? '',
      nomProfessionnel: map['nomProfessionnel'] ?? '',
      specialite: map['specialite'] ?? '',
      anciennete: map['anciennete'] ?? '',
      latitude: map['latitude'] != null ? (map['latitude'] as num).toDouble() : null,
      longitude: map['longitude'] != null ? (map['longitude'] as num).toDouble() : null,
    );
  }
Map<String, dynamic> toMap() {
    return {
      'id': id,
      'username': username,
      'email': email,
      'role': role,
      'nom': nom,
      'dateNaissance': dateNaissance,
      'sexe': sexe,
      'taille': taille,
      'poids': poids,
      'nomProfessionnel': nomProfessionnel,
      'specialite': specialite,
      'anciennete': anciennete,
      'latitude': latitude,
      'longitude': longitude,
    };
  }

  String toJson() => json.encode(toMap());

  factory UserModel.fromJson(String source) {
    final Map<String, dynamic> data = json.decode(source);
    return UserModel.fromMap(data, data['id'] ?? '');
  }
}

class RendezVousModel {
  final String id;
  final String patientId;
  final String doctorId;
  final String patientNom;
  final String doctorNom;
  final DateTime dateTime;
  final String statut; // 'en_attente', 'confirme', 'termine'

  RendezVousModel({
    required this.id,
    required this.patientId,
    required this.doctorId,
    required this.patientNom,
    required this.doctorNom,
    required this.dateTime,
    required this.statut,
  });
}

class MessageModel {
  final String id;
  final String senderId;
  final String receiverId;
  final String contenu;
  final DateTime timestamp;

  MessageModel({
    required this.id,
    required this.senderId,
    required this.receiverId,
    required this.contenu,
    required this.timestamp,
  });
}

// ===== MOCK DATA =====
class MockData {
  static List<UserModel> doctors = [];
  static Future<void> init() async {
    doctors = await DatabaseService().getDoctors();
  }

  static List<RendezVousModel> rendezVous = [
    RendezVousModel(
      id: 'rv1',
      patientId: 'p1',
      doctorId: 'd2',
      patientNom: 'Mr. Slimane',
      doctorNom: 'Dr. Hasni',
      dateTime: DateTime(2026, 5, 22, 9, 30),
      statut: 'confirme',
    ),
    RendezVousModel(
      id: 'rv2',
      patientId: 'p2',
      doctorId: 'd2',
      patientNom: 'Mr. Hafid',
      doctorNom: 'Dr. Hasni',
      dateTime: DateTime(2026, 5, 22, 10, 0),
      statut: 'confirme',
    ),
    RendezVousModel(
      id: 'rv3',
      patientId: 'p3',
      doctorId: 'd2',
      patientNom: 'Mr. Ahmed',
      doctorNom: 'Dr. Hasni',
      dateTime: DateTime(2026, 5, 22, 10, 30),
      statut: 'en_attente',
    ),
    RendezVousModel(
      id: 'rv4',
      patientId: 'p4',
      doctorId: 'd2',
      patientNom: 'Mm. Farah',
      doctorNom: 'Dr. Hasni',
      dateTime: DateTime(2026, 5, 22, 11, 0),
      statut: 'en_attente',
    ),
  ];

  static List<MessageModel> messages = [
    MessageModel(
        id: 'm1',
        senderId: 'p1',
        receiverId: 'd2',
        contenu: 'Bonjour Docteur, j\'ai des douleurs thoraciques.',
        timestamp: DateTime.now().subtract(const Duration(hours: 2))),
    MessageModel(
        id: 'm2',
        senderId: 'd2',
        receiverId: 'p1',
        contenu:
            'Bonjour, je vous recommande de passer une consultation rapidement.',
        timestamp: DateTime.now().subtract(const Duration(hours: 1))),
  ];
}
