import 'dart:developer' as developer;
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'models.dart';

class AppState extends ChangeNotifier {
  // ── Auth State ─────────────────────────
  UserModel? _currentUser;
  static const String _keyUser = 'current_logged_in_user';

  static Future<void> saveUser(UserModel user) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyUser, user.toJson());
  }

  // جلب بيانات المريض الحالي
  static Future<UserModel?> getUser() async {
    final prefs = await SharedPreferences.getInstance();
    final userString = prefs.getString(_keyUser);
    if (userString == null) return null;
    try {
      return UserModel.fromJson(userString);
    } catch (_) {
      return null; // في حال حدوث أي خطأ في التحليل
    }
  }

  // تنظيف الكاش عند تسجيل الخروج
  static Future<void> clearCache() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_keyUser);
  }

  UserModel? get currentUser => _currentUser;

  bool _isLoading = true;
  bool get isLoading => _isLoading;
  bool get isLoggedIn => _currentUser != null;
  bool get isDoctor => _currentUser?.role == 'doctor';
  bool get isPatient => _currentUser?.role == 'patient';

  // 🔥 جلب دور المستخدم من Firestore
  static Future<String?> getUserRole(String uid) async {
    try {
      final doc =
          await FirebaseFirestore.instance.collection('users').doc(uid).get();
      if (doc.exists) {
        return doc.data()?['role'] as String?;
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  /*// ── Doctors ────────────────────────────
  List<UserModel> get allDoctors =>
      MockData.doctors.where((d) => d.role == 'doctor').toList();
*/
  List<UserModel> searchDoctors(String query) {
    if (query.isEmpty) return allDoctors;
    return allDoctors
        .where((d) =>
            (d.nomProfessionnel ?? '')
                .toLowerCase()
                .contains(query.toLowerCase()) ||
            (d.specialite ?? '').toLowerCase().contains(query.toLowerCase()))
        .toList();
  }

  // ── Rendez-vous ────────────────────────
  List<RendezVousModel> get myAppointments {
    if (_currentUser == null) return [];
    return MockData.rendezVous.where((rv) {
      return rv.patientId == _currentUser!.id && rv.statut == 'confirme';
    }).toList();
  }

  List<RendezVousModel> get myRendezVous {
    if (isPatient) {
      return MockData.rendezVous
          .where((rv) => rv.patientId == _currentUser!.id)
          .toList();
    } else if (isDoctor) {
      return MockData.rendezVous
          .where((rv) => rv.doctorId == _currentUser!.id)
          .toList();
    }
    return [];
  }

  List<RendezVousModel> get demandesEnAttente {
    return MockData.rendezVous
        .where((rv) => rv.statut == 'en_attente')
        .toList();
  }

  void confirmerRendezVous(String id) {
    final index = MockData.rendezVous.indexWhere((rv) => rv.id == id);
    if (index != -1) {
      final old = MockData.rendezVous[index];
      MockData.rendezVous[index] = RendezVousModel(
        id: old.id,
        patientId: old.patientId,
        doctorId: old.doctorId,
        patientNom: old.patientNom,
        doctorNom: old.doctorNom,
        dateTime: old.dateTime,
        statut: 'confirme',
      );
      notifyListeners();
    }
  }

  void ajouterDemandeRendezVous(String doctorId, String doctorNom) {
    MockData.rendezVous.add(
      RendezVousModel(
        id: 'rv${MockData.rendezVous.length + 1}',
        patientId: _currentUser?.id ?? 'p_new',
        doctorId: doctorId,
        patientNom: _currentUser?.username ?? 'Patient',
        doctorNom: doctorNom,
        dateTime: DateTime.now().add(const Duration(days: 1)),
        statut: 'en_attente',
      ),
    );
    notifyListeners();
  }

  // ── Messages ───────────────────────────
  List<MessageModel> get myMessages => MockData.messages;

  void envoyerMessage(String receiverId, String contenu) {
    MockData.messages.add(
      MessageModel(
        id: 'm${MockData.messages.length + 1}',
        senderId: _currentUser?.id ?? '',
        receiverId: receiverId,
        contenu: contenu,
        timestamp: DateTime.now(),
      ),
    );
    notifyListeners();
  }

  // ── Auth ───────────────────────────────
  void logout() {
    _currentUser = null;
    notifyListeners();
  }

  void checkAndLoadUserData(BuildContext context, Widget loginScreen) async {
    developer.log('open....');

    _isLoading = true;
    notifyListeners();

    UserModel? cachedUser = await getUser();

    if (cachedUser != null) {
      developer.log('ok!');
      _currentUser = cachedUser;
      _isLoading = false;
      notifyListeners(); // تحديث الواجهات فوراً بالبيانات المحلية
      return;
    }

    // إذا كان الكاش فارغاً، نتأكد من الفايربيز
    final currentFirebaseUser = FirebaseAuth.instance.currentUser;

    if (currentFirebaseUser != null) {
      try {
        final doc = await FirebaseFirestore.instance
            .collection('users')
            .doc(currentFirebaseUser.uid)
            .get();

        if (doc.exists && doc.data() != null) {
          _currentUser = UserModel.fromMap(doc.data()!, doc.id);
          developer.log('User Data: ${_currentUser!.toJson()}');
          await saveUser(_currentUser!); // إصلاح وملء الكاش تلقائياً 🛠️
          _isLoading = false;
          notifyListeners();
          return;
        }
      } catch (e) {
        print("Erreur AppState: $e");
        developer.log('error');
      }
    }
    developer.log('out----');

    if (context.mounted) {
      handleForceLogout(context, loginScreen);
    }
  }

  /// 🔥 2. دالة تسجيل الخروج الموحدة والمحمية (تستدعى من أي مكان في التطبيق بـ سطر واحد)
  void handleForceLogout(BuildContext context, Widget loginScreen) async {
    _currentUser = null;
    _isLoading = false;
    notifyListeners(); // تصفير الحالة في الذاكرة فوراً

    await clearCache(); // تنظيف الذاكرة المحلية للكاش
    await FirebaseAuth.instance.signOut(); // تسجيل الخروج من فايربيز

    if (!context.mounted) return;

    // توجيه المستخدم لصفحة تسجيل الدخول وتطهير سجل التنقل (Stack)
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => loginScreen),
      (route) => false,
    );
  }

// أضف هذه المتغيرات والدوال داخل كلاس AppState المتواجد لديك سابقاً:

  List<UserModel> _allDoctors = [];
  bool _loadingDoctors = false;

  List<UserModel> get allDoctors => _allDoctors;
  bool get loadingDoctors => _loadingDoctors;

// دالة لجلب الأطباء مرة واحدة فقط وتخزينهم في الذاكرة
  Future<void> loadDoctorsIfNeeded() async {
    if (_allDoctors.isNotEmpty) return; // إذا تم جلبهم سابقاً لا تفعل شيء ✅

    _loadingDoctors = true;
    notifyListeners();

    try {
      _allDoctors = await DatabaseService().getDoctors();
    } catch (e) {
      print("Error loading doctors into AppState: $e");
    } finally {
      _loadingDoctors = false;
      notifyListeners();
    }
  }
}
