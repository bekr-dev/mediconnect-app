import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../theme/app_theme.dart';
import '../patient/patient_home_screen.dart';

class AppValidators {
  static String? required(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Ce champ est obligatoire';
    }
    return null;
  }

  static String? email(String? value) {
    if (value == null || value.isEmpty) return 'Ce champ est obligatoire';
    final emailRegex = RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$');
    if (!emailRegex.hasMatch(value)) return 'Email invalide';
    return null;
  }

  static String? password(String? value) {
    if (value == null || value.isEmpty) return 'Ce champ est obligatoire';
    if (value.length < 6) return 'Minimum 6 caractères';
    if (value.length > 50) return 'Maximum 50 caractères';
    return null;
  }
}

class RegisterPatientScreen extends StatefulWidget {
  final String? googleUid;
  final String? googleEmail;
  final String? googleName;

  const RegisterPatientScreen({
    super.key,
    this.googleUid,
    this.googleEmail,
    this.googleName,
  });

  @override
  State<RegisterPatientScreen> createState() => _RegisterPatientScreenState();
}

class _RegisterPatientScreenState extends State<RegisterPatientScreen> {
  final _formKey = GlobalKey<FormState>();
  final _usernameController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _nomController = TextEditingController();
  final _dateController = TextEditingController();
  final _tailleController = TextEditingController();
  final _poidsController = TextEditingController();
  String _sexe = 'Homme';
  bool _loading = false;

  bool get _isGoogleUser => widget.googleUid != null;

  @override
  void initState() {
    super.initState();
    if (widget.googleEmail != null) {
      _emailController.text = widget.googleEmail!;
    }
    if (widget.googleName != null) {
      _nomController.text = widget.googleName!;
    }
  }

  @override
  void dispose() {
    _usernameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _nomController.dispose();
    _dateController.dispose();
    _tailleController.dispose();
    _poidsController.dispose();
    super.dispose();
  }

  void _finish() async {
    setState(() => _loading = true);

    try {
      String uid;

      if (_isGoogleUser) {
        uid = widget.googleUid!;
      } else {
        final UserCredential userCredential =
            await FirebaseAuth.instance.createUserWithEmailAndPassword(
          email: _emailController.text.trim(),
          password: _passwordController.text.trim(),
        );
        uid = userCredential.user!.uid;
      }

      await FirebaseFirestore.instance.collection('users').doc(uid).set({
        'uid': uid,
        'username': _usernameController.text.trim(),
        'email': _emailController.text.trim(),
        'nom': _nomController.text.trim(),
        'dateNaissance': _dateController.text,
        'taille': _tailleController.text,
        'poids': _poidsController.text,
        'sexe': _sexe,
        'role': 'patient',
        'authProvider': _isGoogleUser ? 'google' : 'email',
        'createdAt': FieldValue.serverTimestamp(),
      });

      if (!mounted) return;
      final prefs = await SharedPreferences.getInstance();
      final isFirst = prefs.getBool('is_first_time') ?? true;
      if (isFirst) {
        await prefs.setBool('is_first_time', false);
      }
      if (!mounted) return;

      Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (_) => const PatientHomeScreen()),
          (r) => false);
    } catch (e) {
      setState(() => _loading = false);
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erreur: ${e.toString()}')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF0D47A1), Color(0xFF1565C0), Color(0xFFF0F4F8)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            stops: [0.0, 0.3, 0.5],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // ── Header ───────────────────────────────────────────────
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Row(
                  children: [
                    IconButton(
                      icon:
                          const Icon(Icons.arrow_back_ios, color: Colors.white),
                      onPressed: () => Navigator.pop(context),
                    ),
                    Text(
                      'Espace Patient',
                      style: GoogleFonts.poppins(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: Colors.white),
                    ),
                    if (_isGoogleUser) ...[
                      const Spacer(),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              'By',
                              style: GoogleFonts.poppins(
                                  fontSize: 14, color: Colors.white),
                            ),
                            const SizedBox(width: 6),
                            Image.network(
                              'https://www.google.com/favicon.ico',
                              height: 16,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              'Google',
                              style: GoogleFonts.poppins(
                                  fontSize: 11, color: Colors.white),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ],
                ),
              ),

              // ── Body ─────────────────────────────────────────────────
              Expanded(
                child: Container(
                  margin: const EdgeInsets.only(top: 8),
                  decoration: const BoxDecoration(
                    color: Color(0xFFF0F4F8),
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(32),
                        topRight: Radius.circular(32)),
                  ),
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(28),
                    child: Form(
                      key: _formKey,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Informations personnelles',
                            style: GoogleFonts.poppins(
                                fontSize: 20,
                                fontWeight: FontWeight.w700,
                                color: AppColors.textDark),
                          ),
                          Text(
                            'Complétez votre profil patient',
                            style: GoogleFonts.poppins(
                                fontSize: 13, color: AppColors.textGrey),
                          ),
                          const SizedBox(height: 24),

                          // ── Email/Password: ──
                          if (!_isGoogleUser) ...[
                            _buildLabel('Nom d\'utilisateur'),
                            TextFormField(
                              controller: _usernameController,
                              validator: AppValidators.required,
                              decoration: const InputDecoration(
                                  hintText: 'ex: ahmed_123',
                                  prefixIcon: Icon(Icons.person_outline,
                                      color: AppColors.primary)),
                            ),
                            const SizedBox(height: 16),
                            _buildLabel('Email'),
                            TextFormField(
                              controller: _emailController,
                              validator: AppValidators.email,
                              keyboardType: TextInputType.emailAddress,
                              decoration: const InputDecoration(
                                  hintText: 'exemple@mail.com',
                                  prefixIcon: Icon(Icons.email_outlined,
                                      color: AppColors.primary)),
                            ),
                            const SizedBox(height: 16),
                            _buildLabel('Mot de passe'),
                            TextFormField(
                              controller: _passwordController,
                              validator: AppValidators.password,
                              obscureText: true,
                              decoration: const InputDecoration(
                                  hintText: '••••••••',
                                  prefixIcon: Icon(Icons.lock_outline,
                                      color: AppColors.primary)),
                            ),
                            const Padding(
                              padding: EdgeInsets.symmetric(vertical: 20),
                              child: Divider(),
                            ),
                          ],

                          // ──  Username Google ──
                          if (_isGoogleUser) ...[
                            _buildLabel('Nom d\'utilisateur'),
                            TextFormField(
                              controller: _usernameController,
                              validator: AppValidators.required,
                              decoration: const InputDecoration(
                                  hintText: 'ex: ahmed_123',
                                  prefixIcon: Icon(Icons.person_outline,
                                      color: AppColors.primary)),
                            ),
                            const SizedBox(height: 16),

                            // Email read-only Google
                            _buildLabel('Email'),
                            TextFormField(
                              controller: _emailController,
                              readOnly: true,
                              decoration: InputDecoration(
                                prefixIcon: const Icon(Icons.email_outlined,
                                    color: AppColors.primary),
                                filled: true,
                                fillColor: Colors.grey.shade200,
                                suffixIcon: const Icon(Icons.verified,
                                    color: Colors.green, size: 18),
                              ),
                            ),
                            const Padding(
                              padding: EdgeInsets.symmetric(vertical: 20),
                              child: Divider(),
                            ),
                          ],

                          _buildLabel('Nom complet'),
                          TextFormField(
                            controller: _nomController,
                            validator: AppValidators.required,
                            decoration: const InputDecoration(
                                hintText: 'Votre nom complet',
                                prefixIcon: Icon(Icons.person_outline,
                                    color: AppColors.primary)),
                          ),
                          const SizedBox(height: 16),

                          _buildLabel('Date de naissance'),
                          TextFormField(
                            controller: _dateController,
                            validator: AppValidators.required,
                            readOnly: true,
                            onTap: () async {
                              final date = await showDatePicker(
                                context: context,
                                initialDate: DateTime(1990),
                                firstDate: DateTime(1920),
                                lastDate: DateTime.now(),
                              );
                              if (date != null) {
                                _dateController.text =
                                    '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}';
                              }
                            },
                            decoration: const InputDecoration(
                                hintText: 'JJ/MM/AAAA',
                                prefixIcon: Icon(Icons.calendar_today,
                                    color: AppColors.primary)),
                          ),
                          const SizedBox(height: 16),

                          Row(
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    _buildLabel('Taille (cm)'),
                                    TextFormField(
                                      controller: _tailleController,
                                      validator: AppValidators.required,
                                      keyboardType: TextInputType.number,
                                      decoration: const InputDecoration(
                                          hintText: '170',
                                          prefixIcon: Icon(Icons.height,
                                              color: AppColors.primary)),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    _buildLabel('Poids (kg)'),
                                    TextFormField(
                                      controller: _poidsController,
                                      validator: AppValidators.required,
                                      keyboardType: TextInputType.number,
                                      decoration: const InputDecoration(
                                          hintText: '70',
                                          prefixIcon: Icon(
                                              Icons.monitor_weight_outlined,
                                              color: AppColors.primary)),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 16),

                          _buildLabel('Sexe'),
                          Row(
                            children: [
                              _SexeButton(
                                  label: 'Homme',
                                  icon: Icons.male,
                                  selected: _sexe == 'Homme',
                                  onTap: () => setState(() => _sexe = 'Homme')),
                              const SizedBox(width: 12),
                              _SexeButton(
                                  label: 'Femme',
                                  icon: Icons.female,
                                  selected: _sexe == 'Femme',
                                  onTap: () => setState(() => _sexe = 'Femme')),
                            ],
                          ),
                          const SizedBox(height: 32),

                          // ── Terminer ───────────────────────────────
                          SizedBox(
                            width: double.infinity,
                            height: 52,
                            child: ElevatedButton(
                              onPressed: _loading
                                  ? null
                                  : () {
                                      if (_formKey.currentState!.validate()) {
                                        _finish();
                                      }
                                    },
                              child: _loading
                                  ? const SizedBox(
                                      width: 22,
                                      height: 22,
                                      child: CircularProgressIndicator(
                                          color: Colors.white, strokeWidth: 2))
                                  : Text(
                                      'Terminer',
                                      style: GoogleFonts.poppins(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w600,
                                          color: Colors.white),
                                    ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLabel(String text) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Text(
          text,
          style: GoogleFonts.poppins(
              fontSize: 14,
              fontWeight: FontWeight.w500,
              color: AppColors.textDark),
        ),
      );
}

// ── _SexeButton ────────────────────────────────────────────────────────────
class _SexeButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;

  const _SexeButton({
    required this.label,
    required this.icon,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
        decoration: BoxDecoration(
          color: selected ? AppColors.primary : Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
              color: selected ? AppColors.primary : Colors.grey.shade300),
        ),
        child: Row(
          children: [
            Icon(icon,
                color: selected ? Colors.white : AppColors.textGrey, size: 20),
            const SizedBox(width: 8),
            Text(
              label,
              style: GoogleFonts.poppins(
                  color: selected ? Colors.white : AppColors.textGrey,
                  fontWeight: FontWeight.w500),
            ),
          ],
        ),
      ),
    );
  }
}
