import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../theme/app_theme.dart';

class PatientAppointmentsScreen extends StatelessWidget {
  const PatientAppointmentsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text('Mes rendez-vous',
            style: GoogleFonts.poppins(
                fontWeight: FontWeight.w700, color: AppColors.textDark)),
        backgroundColor: Colors.white,
        elevation: 0,
        automaticallyImplyLeading: false,
      ),
      // 🔥 جلب المواعيد من Firestore حسب uid المريض
      body: uid == null
          ? Center(child: Text('Non connecté', style: GoogleFonts.poppins()))
          : StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('rendezVous')
                  .where('patientId', isEqualTo: uid)
                  .orderBy('dateTime')
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.hasError) {
                  // هذا السطر سيخبرنا بالسبب الحقيقي (Index, Permission, etc.)
                  debugPrint('!!! Firestore Error: ${snapshot.error}');
                }
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }

                final docs = snapshot.data?.docs ?? [];

                return ListView(
                  padding: const EdgeInsets.all(20),
                  children: [
                    // بطاقة الإحصاء
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                            colors: [Color(0xFF1565C0), Color(0xFF26C6DA)]),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(children: [
                        const Icon(Icons.calendar_month,
                            color: Colors.white, size: 40),
                        const SizedBox(width: 16),
                        Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('${docs.length} rendez-vous',
                                  style: GoogleFonts.poppins(
                                      color: Colors.white,
                                      fontSize: 18,
                                      fontWeight: FontWeight.w700)),
                              Text('au total',
                                  style: GoogleFonts.poppins(
                                      color: Colors.white70, fontSize: 13)),
                            ]),
                      ]),
                    ),
                    const SizedBox(height: 20),

                    if (docs.isEmpty)
                      Center(
                        child: Padding(
                          padding: const EdgeInsets.only(top: 40),
                          child: Column(children: [
                            const Icon(Icons.calendar_today_outlined,
                                size: 60, color: AppColors.textGrey),
                            const SizedBox(height: 12),
                            Text('Aucun rendez-vous prévu',
                                style: GoogleFonts.poppins(
                                    color: AppColors.textGrey)),
                          ]),
                        ),
                      )
                    else
                      ...docs.map((doc) {
                        final data = doc.data() as Map<String, dynamic>;
                        final dateTime =
                            (data['dateTime'] as Timestamp).toDate();
                        return _RdvCard(
                          docId: doc.id, // أضف هذا للتعامل مع الحذف مستقبلاً
                          data: data, // نمرر الـ Map كاملة هنا 🔥
                          doctor: data['doctorNom'] ?? '',
                          specialite: data['specialite'] ?? '',
                          date:
                              '${dateTime.day}/${dateTime.month}/${dateTime.year}',
                          heure:
                              '${dateTime.hour.toString().padLeft(2, '0')}:${dateTime.minute.toString().padLeft(2, '0')}',
                          status: data['statut'] ?? 'en_attente',
                        );
                      }),
                  ],
                );
              },
            ),
    );
  }
}

class _RdvCard extends StatelessWidget {
  final String docId;
  final Map<String, dynamic> data; // لاستخراج الـ motif و type و modePaiement
  final String doctor, specialite, date, heure, status;

  const _RdvCard({
    required this.docId,
    required this.data,
    required this.doctor,
    required this.specialite,
    required this.date,
    required this.heure,
    required this.status,
  });

  void _showDetails(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        insetPadding: const EdgeInsets.symmetric(horizontal: 20),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min, // ليأخذ الديالوج حجم المحتوى فقط
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Détails du Rendez-vous',
                    style: GoogleFonts.poppins(
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textDark,
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.close, color: AppColors.textGrey),
                  ),
                ],
              ),
              const SizedBox(height: 20),

              // بيانات الطبيب
              _detailRow(Icons.person_outline, 'Médecin', doctor),
              _detailRow(Icons.category_outlined, 'Spécialité', specialite),
              _detailRow(Icons.videocam_outlined, 'Type',
                  data['type'] ?? 'Consultation'),

              const Divider(height: 30),

              // بيانات الوقت والسبب
              _detailRow(Icons.calendar_today_outlined, 'Date', date),
              _detailRow(Icons.access_time, 'Heure', heure),
              _detailRow(Icons.description_outlined, 'Motif',
                  data['motif'] ?? 'Aucun motif'),

              const Divider(height: 30),

              // الدفع والحالة
              _detailRow(Icons.payment, 'Paiement',
                  data['modePaiement'] ?? 'Non spécifié'),
              _detailRow(Icons.info_outline, 'Statut',
                  status == 'confirme' ? 'Confirmé' : 'En attente',
                  color: status == 'confirme'
                      ? AppColors.success
                      : AppColors.warning),

              const SizedBox(height: 30),

              // أزرار التحكم
              Row(
                children: [
                  if (status != 'confirme')
                    Expanded(
                      child: TextButton(
                        onPressed: () async {
                          await FirebaseFirestore.instance
                              .collection('rendezVous')
                              .doc(docId)
                              .delete();
                          Navigator.pop(context);
                        },
                        child: Text('Annuler',
                            style: GoogleFonts.poppins(color: Colors.red)),
                      ),
                    ),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () => Navigator.pop(context),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primary,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                      ),
                      child: Text('Fermer',
                          style: GoogleFonts.poppins(color: Colors.white)),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _detailRow(IconData icon, String label, String value, {Color? color}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Icon(icon, size: 20, color: Colors.blueGrey),
          const SizedBox(width: 12),
          Text('$label: ',
              style:
                  GoogleFonts.poppins(color: Colors.grey[600], fontSize: 13)),
          Expanded(
              child: Text(value,
                  style: GoogleFonts.poppins(
                      fontWeight: FontWeight.w600,
                      color: color ?? Colors.black87))),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final confirmed = data['statut'] == 'confirme';
    final dateTime = data['dateTime'] is Timestamp
        ? (data['dateTime'] as Timestamp).toDate()
        : DateTime.now();
    final heure =
        '${dateTime.hour.toString().padLeft(2, '0')}:${dateTime.minute.toString().padLeft(2, '0')}';

    return GestureDetector(
      onTap: () => _showDetails(context), // تشغيل النافذة المنبثقة عند الضغط
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: confirmed
                ? AppColors.success.withOpacity(0.3)
                : AppColors.warning.withOpacity(0.3),
          ),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10)
          ],
        ),
        child: Row(children: [
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
                color: AppColors.primary.withOpacity(0.1),
                borderRadius: BorderRadius.circular(14)),
            child: const Icon(Icons.medical_services_outlined,
                color: AppColors.primary),
          ),
          const SizedBox(width: 14),
          Expanded(
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(data['doctorNom'] ?? '—',
                  style: GoogleFonts.poppins(
                      fontWeight: FontWeight.w600, color: AppColors.textDark)),
              Text(data['specialite'] ?? '—',
                  style: GoogleFonts.poppins(
                      fontSize: 12, color: AppColors.textGrey)),
              const SizedBox(height: 4),
              Row(children: [
                const Icon(Icons.access_time,
                    size: 12, color: AppColors.textGrey),
                const SizedBox(width: 4),
                Text(heure,
                    style: GoogleFonts.poppins(
                        fontSize: 12, color: AppColors.textGrey)),
              ]),
            ]),
          ),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: confirmed
                    ? AppColors.success.withOpacity(0.1)
                    : AppColors.warning.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                confirmed ? 'Confirmé' : 'En attente',
                style: GoogleFonts.poppins(
                    fontSize: 11,
                    color: confirmed ? AppColors.success : AppColors.warning,
                    fontWeight: FontWeight.w600),
              ),
            ),
            // 🔥 زر إلغاء الموعد
            if (!confirmed)
              TextButton(
                onPressed: () async {
                  await FirebaseFirestore.instance
                      .collection('rendezVous')
                      .doc(docId)
                      .delete();
                },
                child: Text('Annuler',
                    style: GoogleFonts.poppins(
                        color: AppColors.danger, fontSize: 12)),
              ),
          ]),
        ]),
      ),
    );
  }
}
