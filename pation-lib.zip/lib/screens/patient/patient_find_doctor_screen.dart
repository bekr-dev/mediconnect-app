//import 'dart:convert';
//import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
//import 'package:geocoding/geocoding.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:mediconnect/models/app_state.dart';
import 'package:provider/provider.dart';
import '../../theme/app_theme.dart';
import '../../models/models.dart';
//import 'package:mediconnect/models/models.dart';

class PatientFindDoctorScreen extends StatefulWidget {
  const PatientFindDoctorScreen({super.key});
  @override
  State<PatientFindDoctorScreen> createState() =>
      _PatientFindDoctorScreenState();
}

class _PatientFindDoctorScreenState extends State<PatientFindDoctorScreen> {
  final MapController _mapController = MapController();
  final _searchController = TextEditingController();
  String _selectedSpeciality = 'Tous';
  final List<String> _specialities = [
    'Tous',
    'Généraliste',
    'Cardiologue',
    'Pédiatre',
    'Dermatologue'
  ];

  List<dynamic> _combinedSuggestions = [];
  bool _showSuggestions = false;

  Future<void> _fetchSuggestions(
      String input, List<UserModel> allDoctors) async {
    //await MockData.init();

    if (input.length < 3) {
      setState(() {
        _combinedSuggestions = [];
        _showSuggestions = false;
      });
      return;
    }

    // 1. الاقتراحات المحلية (أطباء)
    final localDocs = allDoctors
        .where((d) =>
            d.nomProfessionnel!.toLowerCase().contains(input.toLowerCase()))
        .take(10)
        .toList();
    setState(() {
      _combinedSuggestions =
          localDocs.map((d) => {'type': 'doctor', 'data': d}).toList();
      _showSuggestions = _combinedSuggestions.isNotEmpty;
    });
/*
    // 2. الاقتراحات الخارجية (مناطق في الجزائر)
    final url =
        'https://nominatim.openstreetmap.org/search?q=$input&format=json&limit=20&countrycodes=dz';

    try {
      final response = await http
          .get(Uri.parse(url), headers: {'User-Agent': 'MediConnect_App'});
      if (response.statusCode == 200) {
        final List remoteData = json.decode(response.body);

        setState(() {
          _combinedSuggestions = [
            ...localDocs.map((d) => {'type': 'doctor', 'data': d}),
            ...remoteData.map((r) => {'type': 'area', 'data': r}),
          ];
          _showSuggestions = _combinedSuggestions.isNotEmpty;
        });
      }
    } catch (e) {
      print("Error fetching suggestions: $e");
    }*/
  }

  List<UserModel> _filteredDoctors = [];
  bool _mapView = true;
  String? _selectedDoctorId;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final appState = Provider.of<AppState>(context, listen: false);
      await appState.loadDoctorsIfNeeded(); // جلب الأطباء إلى الذاكرة
      setState(() {
        _filteredDoctors = appState.allDoctors;
      });
    });
  }

  void _filter(List<UserModel> allDoctors) async {
    final query =
        _searchController.text.toLowerCase(); // النص الذي كتبه المستخدم
    setState(() {
      _filteredDoctors = allDoctors.where((d) {
        final matchName = d.nomProfessionnel!.toLowerCase().contains(query);
        final matchSpec = _selectedSpeciality == 'Tous' ||
            d.specialite == _selectedSpeciality;
        return matchName && matchSpec;
      }).toList();
    });

    try {
      // حالة 1: هل النص المكتوب هو اسم طبيب موجود في النتائج؟
      if (_filteredDoctors.isNotEmpty &&
          _filteredDoctors
              .any((d) => d.nomProfessionnel!.toLowerCase().contains(query))) {
        final firstDoc = _filteredDoctors.firstWhere(
            (d) => d.nomProfessionnel!.toLowerCase().contains(query));
        if (firstDoc.latitude != null &&
            firstDoc.longitude != null &&
            _mapView) {
          _mapController.move(
              LatLng(firstDoc.latitude!, firstDoc.longitude!), 14.0);
        }
      }
      // حالة 2: هل النص المكتوب هو اسم منطقة (مدينة/حي)؟
      /*else if (query.length > 3) {
        List<Location> locations = await locationFromAddress(query);
        if (locations.isNotEmpty && _mapView) {
          final loc = locations.first;
          _mapController.move(
              LatLng(loc.latitude, loc.longitude), 12.0); // زوم متوسط للمدينة
        }
      }*/
    } catch (e) {
      // في حال لم يجد العنوان (خطأ في الكتابة مثلاً)
      print("Error : $e");
    }
  }

  void _showRdvDialog(UserModel doctor, String patientName) {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (_) =>
          _RdvSheet(doctor: doctor, patientName: patientName), // <-- تمريره هنا
    );
  }

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);
    final allDoctors = appState.allDoctors;
    final currentPatientName = appState.currentUser?.nom ?? "Patient";

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Stack(
        children: [
          Column(
            children: [
              Container(
                padding: EdgeInsets.only(
                  top: MediaQuery.of(context).padding.top + 12,
                  left: 20,
                  right: 20,
                  bottom: 16,
                ),
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xFF0D47A1), Color(0xFF1E88E5)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(children: [
                      Text('Trouver un médecin',
                          style: GoogleFonts.poppins(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.w700)),
                      const Spacer(),
                      IconButton(
                        icon: Icon(_mapView ? Icons.list : Icons.map_outlined,
                            color: Colors.white),
                        onPressed: () => setState(() => _mapView = !_mapView),
                      ),
                    ]),
                    const SizedBox(height: 12),
                    TextField(
                      controller: _searchController,
                      onChanged: (val) {
                        _filter(allDoctors);
                        _fetchSuggestions(val, allDoctors);
                      },
                      decoration: InputDecoration(
                        hintText: 'Entrer le nom du médecin',
                        hintStyle: GoogleFonts.poppins(
                            color: AppColors.textGrey, fontSize: 14),
                        prefixIcon:
                            const Icon(Icons.search, color: AppColors.primary),
                        suffixIcon: _searchController.text.isNotEmpty
                            ? IconButton(
                                icon: const Icon(Icons.clear,
                                    color: AppColors.textGrey),
                                onPressed: () {
                                  _searchController
                                      .clear(); // مسح النص من الحقل
                                  setState(() {
                                    _showSuggestions =
                                        false; // إخفاء قائمة الاقتراحات
                                    _combinedSuggestions = [];
                                  });
                                  _filter(
                                      allDoctors); // إعادة عرض كل الأطباء بدون فلاتر
                                },
                              )
                            : null,
                        filled: true,
                        fillColor: Colors.white,
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: BorderSide.none),
                        contentPadding:
                            const EdgeInsets.symmetric(vertical: 14),
                      ),
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      height: 36,
                      child: ListView.separated(
                        scrollDirection: Axis.horizontal,
                        itemCount: _specialities.length,
                        separatorBuilder: (_, __) => const SizedBox(width: 8),
                        itemBuilder: (_, i) {
                          final sel = _specialities[i] == _selectedSpeciality;
                          return GestureDetector(
                            onTap: () {
                              setState(
                                  () => _selectedSpeciality = _specialities[i]);
                              _filter(allDoctors);
                            },
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 16, vertical: 8),
                              decoration: BoxDecoration(
                                color: sel
                                    ? Colors.white
                                    : Colors.white.withOpacity(0.2),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Text(_specialities[i],
                                  style: GoogleFonts.poppins(
                                      fontSize: 13,
                                      color: sel
                                          ? AppColors.primary
                                          : Colors.white,
                                      fontWeight: sel
                                          ? FontWeight.w600
                                          : FontWeight.w400)),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: _mapView
                    ? _buildMap(currentPatientName)
                    : _buildList(currentPatientName),
              ),
            ],
          ),
          if (_showSuggestions)
            Positioned(
              top: MediaQuery.of(context).padding.top + 125,
              left: 20,
              right: 20,
              child: Material(
                elevation: 8,
                borderRadius: BorderRadius.circular(14),
                child: Container(
                  constraints: const BoxConstraints(maxHeight: 300),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: ListView.builder(
                    shrinkWrap: true,
                    padding: EdgeInsets.zero,
                    itemCount: _combinedSuggestions.length,
                    itemBuilder: (context, index) {
                      final suggestion = _combinedSuggestions[index];
                      final bool isDoctor = suggestion['type'] == 'doctor';

                      return ListTile(
                        dense: true,
                        leading: Icon(
                          isDoctor ? Icons.person : Icons.location_on,
                          color: isDoctor ? AppColors.primary : Colors.orange,
                          size: 20,
                        ),
                        title: Text(
                          isDoctor
                              ? suggestion['data'].nomProfessionnel
                              : suggestion['data']['display_name'],
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: GoogleFonts.poppins(
                              fontSize: 13, color: AppColors.textDark),
                        ),
                        subtitle: Text(
                          isDoctor
                              ? "Médecin - ${suggestion['data'].specialite}"
                              : "Région (Algérie)",
                          style: GoogleFonts.poppins(
                              fontSize: 11, color: AppColors.textGrey),
                        ),
                        onTap: () {
                          if (isDoctor) {
                            final d = suggestion['data'];
                            if (_mapView &&
                                d.latitude != null &&
                                d.longitude != null)
                              _mapController.move(
                                  LatLng(d.latitude, d.longitude), 15.0);

                            _searchController.text = d.nomProfessionnel;
                          } /*else {
                            final lat = double.parse(
                                suggestion['data']['lat']?.toString() ?? '');
                            final lon = double.parse(
                                suggestion['data']['lon']?.toString() ?? '');
                            if (_mapView && lat != null && lon != null)
                              _mapController.move(LatLng(lat, lon), 12.0);
                            _searchController.text =
                                suggestion['data']['display_name'];
                          }*/
                          setState(() {
                            _showSuggestions = false;
                            _filter(allDoctors);
                          });
                        },
                      );
                    },
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildMap(String patientName) {
    return FlutterMap(
      mapController: _mapController, // <--- ضروري جداً لتحريك الخريطة
      options: const MapOptions(
        initialCenter: LatLng(35.9290, 0.0900),
        initialZoom: 14,
      ),
      children: [
        TileLayer(
          urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
          userAgentPackageName: 'com.mediconnect.app',
        ),
        MarkerLayer(
          markers: _filteredDoctors.map((d) {
            final isSelected = _selectedDoctorId == d.id;
            return Marker(
              point: LatLng(d.latitude!, d.longitude!),
              width: 80,
              height: 80,
              child: GestureDetector(
                onTap: () {
                  setState(() => _selectedDoctorId = d.id);
                  _showRdvDialog(d, patientName);
                },
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: isSelected ? AppColors.primary : Colors.white,
                        shape: BoxShape.circle,
                        boxShadow: [
                          const BoxShadow(color: Colors.black26, blurRadius: 8)
                        ],
                        border: Border.all(color: AppColors.primary, width: 2),
                      ),
                      child: Icon(Icons.medical_services,
                          color: isSelected ? Colors.white : AppColors.primary,
                          size: 22),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(8),
                        boxShadow: [
                          const BoxShadow(color: Colors.black12, blurRadius: 4)
                        ],
                      ),
                      child: Text(d.nomProfessionnel!,
                          style: GoogleFonts.poppins(
                              fontSize: 9,
                              fontWeight: FontWeight.w600,
                              color: AppColors.textDark)),
                    ),
                  ],
                ),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildList(String patientName) {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _filteredDoctors.length,
      itemBuilder: (_, i) {
        final d = _filteredDoctors[i];
        return _DoctorCard(
            doctor: d, onRdv: () => _showRdvDialog(d, patientName));
      },
    );
  }
}

class _DoctorCard extends StatelessWidget {
  final UserModel doctor;
  final VoidCallback onRdv;
  const _DoctorCard({required this.doctor, required this.onRdv});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 10)
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              color: AppColors.primary.withOpacity(0.1),
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Icon(Icons.person, color: AppColors.primary, size: 30),
          ),
          const SizedBox(width: 14),
          Expanded(
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(doctor.nomProfessionnel!,
                  style: GoogleFonts.poppins(
                      fontWeight: FontWeight.w600, color: AppColors.textDark)),
              Text(doctor.specialite!,
                  style: GoogleFonts.poppins(
                      fontSize: 12, color: AppColors.primary)),
              Text("${doctor.anciennete} d'expérience",
                  style: GoogleFonts.poppins(
                      fontSize: 12, color: AppColors.textGrey)),
              Row(children: [
                ...List.generate(
                    5,
                    (i) => Icon(Icons.star,
                        size: 14,
                        color: i < 4 ? Colors.amber : Colors.grey.shade300)),
                Text(' 4.0',
                    style: GoogleFonts.poppins(
                        fontSize: 11, color: AppColors.textGrey)),
              ]),
            ]),
          ),
          ElevatedButton(
            onPressed: onRdv,
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primary,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
            ),
            child: Text('RDV',
                style: GoogleFonts.poppins(
                    fontSize: 12,
                    color: Colors.white,
                    fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );
  }
}

class _RdvSheet extends StatefulWidget {
  final UserModel doctor;

  final String patientName; // 🔥 إضافة هذا السطر

  const _RdvSheet({required this.doctor, required this.patientName});

  @override
  State<_RdvSheet> createState() => _RdvSheetState();
}

class _RdvSheetState extends State<_RdvSheet> {
  bool _loading = false;
  String _selectedType = 'Nouveau contrôle';
  String _selectedPayment = 'Au cabinet';
  final TextEditingController _motifController = TextEditingController();
  String? _motifError;
  final List<String> _types = [
    'Nouveau contrôle',
    'Consultation de suivi',
    'Urgence'
  ];
  final List<String> _payments = ['En ligne', 'Au cabinet'];

  @override
  void dispose() {
    _motifController.dispose();
    super.dispose();
  }

  Future<void> _demanderRdv() async {
    if (_motifController.text.trim().isEmpty) {
      setState(() {
        _motifError = 'Ce champ est obligatoire'; // الرسالة المطلوبة بالفرنسية
      });
      return;
    }
    setState(() {
      _loading = true;
      _motifError = null; // تصفير الخطأ عند النجاح
    });

    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return;

/*      final patientDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .get();
      final patientNom = patientDoc.data()?['nom'] ?? 'Patient';*/

      await FirebaseFirestore.instance.collection('rendezVous').add({
        'patientId': user.uid,
        'patientNom': widget.patientName,
        'doctorId': widget.doctor.id,
        'doctorNom': widget.doctor.nomProfessionnel,
        'specialite': widget.doctor.specialite,
        'type': _selectedType,
        'motif': _motifController.text.trim(),
        'modePaiement': _selectedPayment,
        'dateTime':
            Timestamp.fromDate(DateTime.now().add(const Duration(days: 1))),
        'statut': 'en_attente',
        'createdAt': FieldValue.serverTimestamp(),
      });

      if (!mounted) return;
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Demande envoyée à ${widget.doctor.nomProfessionnel} !',
              style: GoogleFonts.poppins(color: Colors.white)),
          backgroundColor: AppColors.success,
        ),
      );
    } catch (e) {
      // Handle error
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent, // لجعل الحواف تظهر بشكل دائري
      insetPadding: const EdgeInsets.symmetric(horizontal: 10),
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          color: const Color(0xFFF0F2F5), // لون خلفية فاتح مثل الصورة
          borderRadius: BorderRadius.circular(30),
        ),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min, // ليأخذ الطول حسب المحتوى فقط
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // زر الإغلاق والعنوان
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("Détails du RDV",
                      style: GoogleFonts.poppins(
                          fontWeight: FontWeight.w800,
                          fontSize: 22,
                          color: const Color(0xFF1A237E))),
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: const BoxDecoration(
                          color: Colors.white, shape: BoxShape.circle),
                      child: const Icon(Icons.close,
                          size: 20, color: Colors.black54),
                    ),
                  )
                ],
              ),
              const SizedBox(height: 12),
              const Divider(color: Colors.black12),
              const SizedBox(height: 20),

              _buildLabel("Type de consultation"),
              DropdownButtonFormField<String>(
                value: _selectedType,
                items: _types
                    .map((t) => DropdownMenuItem(
                        value: t,
                        child:
                            Text(t, style: GoogleFonts.poppins(fontSize: 14))))
                    .toList(),
                onChanged: (val) => setState(() => _selectedType = val!),
                decoration: _inputStyle(),
              ),
              const SizedBox(height: 16),

              _buildLabel("Motif de la visite"),
              TextField(
                onChanged: (value) {
                  if (_motifError != null &&
                      !_motifController.text.trim().isEmpty) {
                    setState(
                        () => _motifError = null); // إخفاء الأحمر فور الكتابة
                  } else if (_motifController.text.trim().isEmpty) {
                    setState(() {
                      _motifError =
                          'Ce champ est obligatoire'; // الرسالة المطلوبة بالفرنسية
                    });
                  }
                },
                controller: _motifController,
                maxLines: 2,
                style: GoogleFonts.poppins(fontSize: 14),
                decoration: _inputStyle(
                  hint: "Ex: Douleurs abdominales...",
                  errorText: _motifError,
                ),
              ),
              const SizedBox(height: 20),

              _buildLabel("Mode de paiement"),
              DropdownButtonFormField<String>(
                value: _selectedPayment,
                items: _payments
                    .map((p) => DropdownMenuItem(
                        value: p,
                        child: Text(p,
                            style: GoogleFonts.poppins(
                                fontSize: 14, fontWeight: FontWeight.w500))))
                    .toList(),
                onChanged: (val) => setState(() => _selectedPayment = val!),
                decoration: _inputStyle(),
              ),
              const SizedBox(height: 20),
              Row(children: [
                Container(
                  width: 60,
                  height: 60,
                  decoration: BoxDecoration(
                      color: AppColors.primary.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(16)),
                  child: const Icon(Icons.person,
                      color: AppColors.primary, size: 32),
                ),
                const SizedBox(width: 16),
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(widget.doctor.nomProfessionnel!,
                      style: GoogleFonts.poppins(
                          fontWeight: FontWeight.w700,
                          fontSize: 18,
                          color: AppColors.textDark)),
                  Text(widget.doctor.specialite!,
                      style: GoogleFonts.poppins(color: AppColors.primary)),
                  Text("${widget.doctor.anciennete!} d'expérience",
                      style: GoogleFonts.poppins(
                          fontSize: 12, color: AppColors.textGrey)),
                ]),
              ]),
              const SizedBox(height: 24),

              // زر التأكيد (مثل الصورة تماماً)
              SizedBox(
                width: double.infinity,
                height: 56,
                child: ElevatedButton(
                  onPressed: _loading ? null : _demanderRdv,
                  style: ElevatedButton.styleFrom(
                    backgroundColor:
                        const Color(0xFF1E88E5), // لون أزرق مثل الصورة
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16)),
                    elevation: 0,
                  ),
                  child: _loading
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                              color: Colors.white, strokeWidth: 2))
                      : Text('Confirmer la demande',
                          style: GoogleFonts.poppins(
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                              fontSize: 16)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLabel(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8, left: 4),
      child: Text(text,
          style: GoogleFonts.poppins(
              fontSize: 14,
              color: const Color(0xFF1A237E),
              fontWeight: FontWeight.w600)),
    );
  }

  InputDecoration _inputStyle({String? hint, String? errorText}) {
    return InputDecoration(
      hintText: hint,
      errorText:
          errorText, // هذا هو السطر الذي يسبب الخطأ إذا لم يكن المعامل معرفاً أعلاه
      errorStyle: GoogleFonts.poppins(color: Colors.red, fontSize: 12),
      hintStyle: GoogleFonts.poppins(fontSize: 13, color: Colors.grey),
      filled: true,
      fillColor: Colors.white,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),

      // الإطار الطبيعي
      border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
      enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),

      // إطار الخطأ الأحمر
      errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: Colors.red, width: 1.5)),
      focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: Colors.red, width: 2)),
    );
  }
}
