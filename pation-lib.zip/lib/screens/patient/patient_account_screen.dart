import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../theme/app_theme.dart';
import '../auth/login_screen.dart';

class PatientAccountScreen extends StatelessWidget {
  const PatientAccountScreen({super.key});

  // 🔥 جلب بيانات المريض من Firestore
  Future<Map<String, dynamic>> _getPatientData() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return {};
    try {
      final doc = await FirebaseFirestore.instance.collection('users').doc(uid).get();
      return doc.data() ?? {};
    } catch (_) {
      return {};
    }
  }

  // 🔥 تسجيل الخروج مع Firebase
  Future<void> _logout(BuildContext context) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('Se déconnecter', style: GoogleFonts.poppins(fontWeight: FontWeight.w700)),
        content: Text('Êtes-vous sûr de vouloir vous déconnecter ?',
            style: GoogleFonts.poppins(fontSize: 14)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text('Annuler', style: GoogleFonts.poppins(color: AppColors.textGrey)),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.danger),
            child: Text('Déconnecter', style: GoogleFonts.poppins(color: Colors.white)),
          ),
        ],
      ),
    );

    if (confirm == true) {
      await FirebaseAuth.instance.signOut();
      if (context.mounted) {
        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (_) => const LoginScreen()),
          (r) => false,
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: FutureBuilder<Map<String, dynamic>>(
        future: _getPatientData(),
        builder: (context, snapshot) {
          final data = snapshot.data ?? {};
          final nom = data['nom'] ?? data['username'] ?? 'Patient';
          final dateNaissance = data['dateNaissance'] ?? '—';
          final taille = data['taille'] ?? '—';
          final poids = data['poids'] ?? '—';
          final sexe = data['sexe'] ?? '—';

          return CustomScrollView(slivers: [
            SliverAppBar(
              expandedHeight: 200,
              pinned: true,
              backgroundColor: AppColors.primary,
              automaticallyImplyLeading: false,
              flexibleSpace: FlexibleSpaceBar(
                background: Container(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Color(0xFF0D47A1), Color(0xFF26C6DA)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    const SizedBox(height: 40),
                    Container(
                      width: 80, height: 80,
                      decoration: BoxDecoration(color: Colors.white.withOpacity(0.2), shape: BoxShape.circle),
                      child: const Icon(Icons.person, color: Colors.white, size: 45),
                    ),
                    const SizedBox(height: 12),
                    // 🔥 اسم حقيقي من Firestore
                    snapshot.connectionState == ConnectionState.waiting
                        ? const CircularProgressIndicator(color: Colors.white, strokeWidth: 2)
                        : Text(nom, style: GoogleFonts.poppins(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w700)),
                    Text('Patient', style: GoogleFonts.poppins(color: Colors.white70, fontSize: 13)),
                  ]),
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(children: [
                  // 🔥 بيانات حقيقية من Firestore
                  _InfoCard(items: [
                    {'icon': 'person', 'label': 'Nom', 'value': nom},
                    {'icon': 'calendar_today', 'label': 'Date de naissance', 'value': dateNaissance},
                    {'icon': 'height', 'label': 'Taille / Poids', 'value': '$taille / $poids'},
                    {'icon': 'male', 'label': 'Sexe', 'value': sexe},
                  ]),
                  const SizedBox(height: 16),
                  _MenuItem(icon: Icons.settings_outlined, label: 'Paramètres', onTap: () {}),
                  _MenuItem(icon: Icons.help_outline, label: 'Aide', onTap: () {}),
                  _MenuItem(icon: Icons.privacy_tip_outlined, label: 'Confidentialité', onTap: () {}),
                  const SizedBox(height: 8),
                  // 🔥 تسجيل خروج حقيقي
                  SizedBox(
                    width: double.infinity, height: 50,
                    child: OutlinedButton(
                      onPressed: () => _logout(context),
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: AppColors.danger),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                      child: Text('Se déconnecter',
                          style: GoogleFonts.poppins(color: AppColors.danger, fontWeight: FontWeight.w600)),
                    ),
                  ),
                ]),
              ),
            ),
          ]);
        },
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  final List<Map<String, String>> items;
  const _InfoCard({required this.items});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10)],
      ),
      child: Column(children: items.asMap().entries.map((e) {
        final item = e.value;
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
          decoration: BoxDecoration(
            border: e.key < items.length - 1
                ? Border(bottom: BorderSide(color: Colors.grey.shade100))
                : null,
          ),
          child: Row(children: [
            Icon(_getIcon(item['icon']!), color: AppColors.primary, size: 20),
            const SizedBox(width: 14),
            Text(item['label']!, style: GoogleFonts.poppins(color: AppColors.textGrey, fontSize: 13)),
            const Spacer(),
            Text(item['value']!, style: GoogleFonts.poppins(
                color: AppColors.textDark, fontWeight: FontWeight.w500, fontSize: 13)),
          ]),
        );
      }).toList()),
    );
  }

  IconData _getIcon(String name) {
    switch (name) {
      case 'person': return Icons.person_outline;
      case 'calendar_today': return Icons.calendar_today_outlined;
      case 'height': return Icons.height;
      case 'male': return Icons.male;
      default: return Icons.info_outline;
    }
  }
}

class _MenuItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _MenuItem({required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8)],
      ),
      child: ListTile(
        leading: Icon(icon, color: AppColors.primary),
        title: Text(label, style: GoogleFonts.poppins(color: AppColors.textDark, fontWeight: FontWeight.w500)),
        trailing: const Icon(Icons.arrow_forward_ios, size: 16, color: AppColors.textGrey),
        onTap: onTap,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
    );
  }
}
